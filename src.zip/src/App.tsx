import { useState } from "react";
import "./App.css";
import { MenuItem } from "./entities/entities"; 



function App() {
  const [isChooseFoodPage, setIsChooseFoodPage] = useState(false);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([
    {
      id: 1,
      name: "Hamburguesa de Pollo",
      quantity: 40,
      desc: "Hamburguesa de pollo frito - … y mayonesa",
      price: 24,
      image: "C:\Users\laura\FoodApp\public\images\cb.png",
    },
    {
      id: 2,
      name: "Patatas Fritas",
      quantity: 40,
      desc: "Patatas Fritas",
      price: 24,
      image: "chips.png",
    },
    {
      id: 3,
      name: "Hamburguesas Vegetarianas",
      quantity: 40,
      desc: "Hamburguesas Vegetarianas",
      price: 24,
      image: "hv.png",
    },
    {
      id: 4,
      name: "Helado",
      quantity: 40,
      desc: "Helado",
      price: 24,
      image: "ice.png",
    },
  ]);

  return (
    <div className="App">
      <button
        className="toggleButton"
        onClick={() => setIsChooseFoodPage(!isChooseFoodPage)}
      >
        {isChooseFoodPage ? "Disponibilidad" : "Pedir Comida"}
      </button>

      <h3 className="title">Comida Rápida Online</h3>
      {isChooseFoodPage && (
        <>
          <h4 className="subTitle">Menús</h4>
          <ul className="ulApp">
            {menuItems.map((item) => (
              <li key={item.id} className="liApp">
                <p>{item.name}</p>
                <p>#{item.quantity}</p>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

export default App;
